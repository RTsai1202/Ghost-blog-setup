// ===== 全局變數與狀態管理 =====
const AppState = {
    isArticlePage: null,
    content: null,
    headers: [],
    activeHeaderId: null,

    init() {
        this.isArticlePage = document.body.classList.contains('post-template');
        this.content = document.querySelector('.gh-content');

        if (this.content) {
            // 取得所有標題元素
            const allHeaders = Array.from(this.content.querySelectorAll('h1, h2, h3, h4, h5, h6'));

            // 過濾掉位於 Toggle card、Callout card 等卡片元件內的標題
            // 這些不是真正的文章章節標題
            this.headers = allHeaders.filter(header => {
                // 檢查是否在 Ghost 卡片元件內
                const isInToggleCard = header.closest('.kg-toggle-card');
                const isInCalloutCard = header.closest('.kg-callout-card');
                const isInProductCard = header.closest('.kg-product-card');
                const isInHeaderCard = header.closest('.kg-header-card');

                // 只保留不在這些卡片內的標題
                return !isInToggleCard && !isInCalloutCard && !isInProductCard && !isInHeaderCard;
            });
        } else {
            this.headers = [];
        }
    }
};

// ===== 功能旗標（可在瀏覽器主控台覆寫 window.__FEATURES__） =====
window.__FEATURES__ = Object.assign({
    externalLinks: true,
    jsonLd: true,
    shareButtons: true,
    readingInfo: true,
    imageOptimize: true,
    tableResponsive: true,
    breadcrumbs: true
}, window.__FEATURES__ || {});

const Features = {
    on(name) { return !!(window.__FEATURES__ && window.__FEATURES__[name]); }
};

// ===== 工具函數 =====
const Utils = {
    // 統一的活動標題查找邏輯
    findActiveHeader(headers) {
        if (!headers || headers.length === 0) return null;

        const scrollPosition = window.scrollY;
        const viewportHeight = window.innerHeight;
        const triggerPoint = scrollPosition + viewportHeight * 0.3; // 調整觸發點為視窗頂部 30% 處

        let lastPassedHeader = null;

        // 找到最後一個「已經滾過」的標題
        // 邏輯：標題的位置 <= 當前滾動位置 + 視窗高度的 30%
        for (let i = 0; i < headers.length; i++) {
            const header = headers[i];
            if (!document.body.contains(header)) continue;
            if (!header.id) continue; // 跳過沒有 ID 的標題

            const headerPos = header.getBoundingClientRect().top + window.scrollY;

            if (headerPos <= triggerPoint) {
                lastPassedHeader = header;
            } else {
                // 一旦遇到還沒滾過的標題，就停止
                // 因為 headers 是按 DOM 順序排列的
                break;
            }
        }

        // 如果找到已經滾過的標題，返回它
        if (lastPassedHeader && lastPassedHeader.id) {
            return lastPassedHeader.id;
        }

        // Fallback: 如果還沒滾到任何標題，返回第一個有 ID 的標題
        for (let i = 0; i < headers.length; i++) {
            if (headers[i].id) {
                return headers[i].id;
            }
        }

        return null;
    },

    // 統一的標題 ID 設定
    ensureHeaderIds(headers) {
        headers.forEach((header, index) => {
            if (!header.id) {
                header.id = `article-toc-${index}`;
            }
        });
    },

    // 創建目錄項目的統一函數（移除未使用參數）
    createTocItem(header) {
        const listItem = document.createElement('li');
        listItem.className = `toc-common-item toc-${header.tagName.toLowerCase()}`;

        const link = document.createElement('a');
        link.href = `#${header.id}`;

        // [MODIFIED] Clone header to safely remove anchor link text without affecting DOM
        const headerClone = header.cloneNode(true);
        const anchorLink = headerClone.querySelector('.heading-anchor-link');
        if (anchorLink) {
            anchorLink.remove();
        }
        link.textContent = headerClone.textContent.trim();

        link.className = 'toc-common-link';
        link.setAttribute('data-id', header.id);

        listItem.appendChild(link);
        return listItem;
    },

    // 統一的滾動到標題功能
    scrollToHeader(targetId) {
        const targetElement = document.getElementById(targetId);
        if (targetElement) {
            targetElement.scrollIntoView({ behavior: 'smooth' });

            // 高亮顯示
            targetElement.classList.add('highlight');
            setTimeout(() => {
                targetElement.classList.remove('highlight');
            }, 1500);
        }
    },

    // 統一的活動項目更新
    updateActiveItems(containerselector, activeHeaderId) {
        const container = document.querySelector(containerselector);
        if (!container) return;

        // 移除所有活動狀態
        container.querySelectorAll('.toc-common-item').forEach(item => {
            item.classList.remove('active');
        });

        // 添加當前位置活動狀態
        if (activeHeaderId) {
            const activeItem = container.querySelector(`a[data-id="${activeHeaderId}"]`);
            if (activeItem && activeItem.parentElement) {
                activeItem.parentElement.classList.add('active');

                // 自動滾動到視圖中
                this.scrollItemIntoView(container, activeItem.parentElement);
            }
        }
    },

    scrollItemIntoView(container, item) {
        const content = container.querySelector('.toc-content, .mobile-toc-content, .article-toc-content');
        if (!content || content.style.display === 'none') return;

        const itemOffsetTop = item.offsetTop;
        const contentScrollTop = content.scrollTop;
        const contentHeight = content.clientHeight;

        if (itemOffsetTop < contentScrollTop || itemOffsetTop > contentScrollTop + contentHeight - 50) {
            content.scrollTop = itemOffsetTop - contentHeight / 2;
        }
    }
};

// ===== 文章內連結處理（全部新分頁開啟）=====
const ContentLinks = {
    init() {
        if (!AppState.content) return;

        const currentHost = window.location.host;
        const anchors = AppState.content.querySelectorAll('a[href]');

        anchors.forEach(a => {
            const href = a.getAttribute('href');
            // 排除錨點、mailto、tel、JS、下載
            if (!href || href.startsWith('#') || href.startsWith('mailto:') || href.startsWith('tel:') || href.startsWith('javascript:') || a.hasAttribute('download')) {
                return;
            }

            try {
                // 只要是 http/https 連結，一律開新分頁
                // 不管是站內還是站外，只要是在文章內容區塊內的連結，都開新分頁
                a.setAttribute('target', '_blank');

                // rel 處理：全數加上 noopener
                const rel = (a.getAttribute('rel') || '').split(/\s+/).filter(Boolean);
                if (!rel.includes('noopener')) rel.push('noopener');

                // 只有站外連結才加 noreferrer 和 external
                const url = new URL(href, window.location.href);
                if (url.host !== currentHost) {
                    ['noreferrer', 'external'].forEach(v => { if (!rel.includes(v)) rel.push(v); });
                }
                a.setAttribute('rel', rel.join(' '));

                // 防重複初始化
                if (a.dataset.bgTabInitialized === 'true') return;
                a.dataset.bgTabInitialized = 'true';

                // 嘗試模擬 Cmd+Click (Mac) 或 Ctrl+Click (Win)
                // 這會試圖觸發瀏覽器的「背景分頁開啟」行為
                a.addEventListener('click', (e) => {
                    // 如果使用者真的按了按鍵，就別干擾
                    if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;

                    e.preventDefault();

                    // 創建一個模擬的滑鼠點擊事件，帶有 Meta/Ctrl 鍵
                    const mouseEvent = new MouseEvent('click', {
                        view: window,
                        bubbles: true,
                        cancelable: true,
                        metaKey: true, // Mac: Cmd
                        ctrlKey: true  // Win: Ctrl
                    });

                    // 為了避免無限迴圈，我們需要一個臨時連結
                    // 或者我們直接對這個連結觸發，但要小心遞迴
                    // 最安全的方式：建立一個隱藏的臨時連結來觸發
                    const tempLink = document.createElement('a');
                    tempLink.href = a.href;
                    tempLink.style.display = 'none';
                    document.body.appendChild(tempLink);

                    // 對臨時連結觸發 Cmd+Click
                    // 注意：現代瀏覽器可能會因為 isTrusted=false 而忽略這個修飾鍵行為
                    // 但這是最接近「透過 cmd+click」的實作方式
                    tempLink.dispatchEvent(mouseEvent);

                    document.body.removeChild(tempLink);
                });

            } catch (e) {
                // 忽略解析錯誤
            }
        });
    }
};

// ===== Kit 電子報表單 AJAX 處理 =====
const KitForm = {
    init() {
        // 確保 DOM 已經完全載入
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.bindEvents());
        } else {
            this.bindEvents();
        }
    },

    bindEvents() {
        const form = document.querySelector('.custom-subscribe-form');
        console.log('KitForm init: form found?', !!form); // Debug log

        // [MODIFIED] Disable JS interception to allow standard form submission to new tab
        return;

        if (!form) return;

        // 移除舊的監聽器（防止重複綁定）
        const newForm = form.cloneNode(true);
        form.parentNode.replaceChild(newForm, form);

        newForm.addEventListener('submit', async (e) => {
            console.log('KitForm: submit intercepted'); // Debug log
            e.preventDefault();

            const button = newForm.querySelector('button');
            const originalText = button.querySelector('span:not(.loader)');
            const loader = button.querySelector('.loader');

            // 鎖定按鈕狀態
            button.classList.add('gh-btn-icon');
            if (originalText) originalText.style.opacity = '0';
            if (loader) loader.style.display = 'inline-block';
            button.disabled = true;

            try {
                const formData = new FormData(newForm);
                const action = newForm.getAttribute('action');

                // 使用 fetch 發送請求
                // 注意：Kit 的 API 對於 AJAX 請求通常需要 'Accept': 'application/json'
                // 並且可能會因為 CORS 而失敗，如果失敗我們需要 fallback
                const response = await fetch(action, {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'Accept': 'application/json'
                    }
                });

                console.log('KitForm: response status', response.status); // Debug log

                if (response.ok) {
                    // 成功：顯示成功 Toast
                    this.showToast('success', '訂閱成功！請去信箱確認您的訂閱。');
                    newForm.reset();
                } else {
                    throw new Error('Subscription failed');
                }
            } catch (error) {
                console.error('Kit subscription error:', error);
                // 如果 AJAX 失敗 (例如 CORS)，我們嘗試用傳統方式提交
                // 但為了避免跳轉，我們可以顯示一個提示，或者就讓它跳轉
                // 這裡我們先顯示錯誤 Toast
                this.showToast('error', '訂閱連線問題，請檢查網路或稍後再試。');
            } finally {
                // 恢復按鈕狀態
                button.classList.remove('gh-btn-icon');
                if (originalText) originalText.style.opacity = '1';
                if (loader) loader.style.display = 'none';
                button.disabled = false;
            }
        });
    },

    showToast(type, message) {
        // 移除舊的 Toast
        const oldToast = document.querySelector('.system-toast');
        if (oldToast) oldToast.remove();

        // 建立新 Toast
        const toast = document.createElement('div');
        toast.className = `system-toast ${type === 'success' ? 'message-success' : 'message-error'}`;

        // 設定樣式
        toast.style.position = 'fixed';
        toast.style.top = '20px';
        toast.style.left = '50%';
        toast.style.transform = 'translateX(-50%)';
        toast.style.zIndex = '9999';
        toast.style.padding = '12px 24px';
        toast.style.borderRadius = '8px';
        toast.style.boxShadow = '0 4px 20px rgba(0,0,0,0.3)';
        toast.style.backdropFilter = 'blur(10px)';
        toast.style.border = type === 'success' ? '1px solid #00f2ff' : '1px solid #ff0055';
        toast.style.color = '#fff';
        toast.style.fontWeight = '500';
        toast.style.fontSize = '15px';
        toast.style.display = 'flex';
        toast.style.alignItems = 'center';
        toast.style.gap = '10px';
        toast.style.animation = 'toastSlideDown 0.3s ease forwards';

        // 內容
        const icon = type === 'success' ? '✨' : '⚠️';
        toast.innerHTML = `<span>${icon}</span><span>${message}</span>`;

        document.body.appendChild(toast);

        // 3秒後自動消失
        setTimeout(() => {
            toast.style.animation = 'toastFadeOut 0.3s ease forwards';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }
};

// ===== 文章內固定目錄模塊 =====
const ArticleTOC = {
    container: null,

    create() {
        if (!AppState.isArticlePage || !AppState.content || AppState.headers.length < 2) {
            return null;
        }

        Utils.ensureHeaderIds(AppState.headers);

        // 創建目錄容器
        this.container = document.createElement('div');
        this.container.className = 'article-toc-container';

        // 創建標題
        const header = document.createElement('div');
        header.className = 'article-toc-header';

        const title = document.createElement('h4');
        title.className = 'article-toc-title';
        title.textContent = '文章目錄';

        const toggle = document.createElement('span');
        toggle.className = 'article-toc-toggle';
        toggle.innerHTML = '▲';

        header.appendChild(title);
        header.appendChild(toggle);

        // 創建內容
        const content = document.createElement('div');
        content.className = 'article-toc-content';

        const list = document.createElement('ul');
        list.className = 'toc-common-list';

        AppState.headers.forEach(header => {
            const item = Utils.createTocItem(header);
            list.appendChild(item);
        });

        content.appendChild(list);
        this.container.appendChild(header);
        this.container.appendChild(content);

        // 插入到文章開頭
        AppState.content.insertBefore(this.container, AppState.content.firstChild);

        // 預設為收合狀態
        this.container.classList.add('collapsed');

        this.bindEvents();
        // 移除 restoreState()，讓目錄總是保持收合

        return this.container;
    },

    bindEvents() {
        // 點擊導航
        this.container.querySelectorAll('.toc-common-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const targetId = link.getAttribute('href').substring(1);
                Utils.scrollToHeader(targetId);
            });
        });

        // 收合功能
        this.container.querySelector('.article-toc-header').addEventListener('click', () => {
            this.container.classList.toggle('collapsed');
            localStorage.setItem('articleTocState',
                this.container.classList.contains('collapsed') ? 'collapsed' : 'expanded'
            );
        });
    },

    restoreState() {
        const savedState = localStorage.getItem('articleTocState');
        if (savedState === 'collapsed') {
            this.container.classList.add('collapsed');
        }
    },

    updateActive(activeHeaderId) {
        Utils.updateActiveItems('.article-toc-container', activeHeaderId);
    }
};

// ===== 桌面版懸浮目錄模塊 =====
// ===== 桌面版懸浮目錄模塊 (底部膠囊版) =====
const FloatingTOC = {
    container: null,
    fixedTocContainer: null, // 用於判斷何時顯示 (參考文章內 TOC 位置)
    articleTitle: '', // 儲存文章標題 (H1)
    isPinned: false, // 📌 釘住狀態

    create(fixedTocContainer) {
        if (!AppState.isArticlePage || !AppState.content ||
            AppState.headers.length < 2 || !fixedTocContainer ||
            window.innerWidth < 1200) {
            return null;
        }

        this.fixedTocContainer = fixedTocContainer;

        // 創建懸浮目錄
        this.container = document.createElement('div');
        this.container.className = 'toc-floating';
        this.container.style.display = 'none'; // 初始隱藏
        this.container.style.opacity = '0';

        // 取得文章標題 (H1) 並儲存 (用於展開時的標題)
        const articleTitleEl = document.querySelector('.article-title') || document.querySelector('h1');
        this.articleTitle = articleTitleEl ? articleTitleEl.innerText.trim() : '目錄';

        // 標題區域 (收合時顯示當前閱讀章節) - 初始顯示第一個章節
        const title = document.createElement('div');
        title.className = 'toc-title';
        // 初始顯示第一個標題（非 H1）或文章標題作為 fallback
        const firstHeader = AppState.headers[0];
        title.textContent = firstHeader ? firstHeader.innerText.replace(/#\s*$/, '').trim() : this.articleTitle;

        // 內容區域 (包含可滾動的目錄列表)
        const content = document.createElement('div');
        content.className = 'toc-content';

        // 展開時顯示的文章標題 (H1 Header) - 放在 toc-content 外面，分隔線上方
        const expandedHeader = document.createElement('div');
        expandedHeader.className = 'toc-expanded-header';
        expandedHeader.textContent = this.articleTitle;

        // 📌 釘住按鈕 - 在展開標題旁邊
        const pinButton = document.createElement('button');
        pinButton.className = 'toc-pin-button';
        pinButton.innerHTML = '📌';
        pinButton.setAttribute('title', '釘住目錄 (保持展開)');
        pinButton.setAttribute('aria-label', 'Pin table of contents');

        // 創建包含標題和釘住按鈕的容器
        const headerRow = document.createElement('div');
        headerRow.className = 'toc-header-row';
        headerRow.appendChild(expandedHeader);
        headerRow.appendChild(pinButton);

        const list = document.createElement('ul');
        list.className = 'toc-common-list';

        AppState.headers.forEach(header => {
            const item = Utils.createTocItem(header);
            list.appendChild(item);
        });

        content.appendChild(list);

        // DOM 順序：toc-title (收合時) → toc-header-row (H1 + 📌) → toc-content (目錄列表)
        this.container.appendChild(title);
        this.container.appendChild(headerRow);  // H1 + Pin 按鈕
        this.container.appendChild(content);

        document.body.appendChild(this.container);

        this.bindEvents();
        this.initPositioning();

        // 初次更新一次標題
        this.updateActive(AppState.activeHeaderId);

        return this.container;
    },

    bindEvents() {
        // 點擊連結滾動
        this.container.querySelectorAll('.toc-common-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const targetId = link.getAttribute('href').substring(1);
                Utils.scrollToHeader(targetId);
                // 點擊後，滑鼠可能會移開，CSS 會自動收合（除非已釘住）
            });
        });

        // 📌 釘住按鈕事件
        const pinButton = this.container.querySelector('.toc-pin-button');
        if (pinButton) {
            pinButton.addEventListener('click', (e) => {
                e.stopPropagation(); // 防止事件冒泡
                this.isPinned = !this.isPinned;

                if (this.isPinned) {
                    this.container.classList.add('is-pinned');
                    pinButton.classList.add('active');
                    pinButton.setAttribute('title', '取消釘住');
                } else {
                    this.container.classList.remove('is-pinned');
                    pinButton.classList.remove('active');
                    pinButton.setAttribute('title', '釘住目錄 (保持展開)');
                }
            });
        }

        // 【新增】Hover 時自動捲動到當前章節
        this.container.addEventListener('mouseenter', () => {
            this.scrollToActive();
        });
    },

    scrollToActive() {
        // 確保當前條目在視野中
        const activeItem = this.container.querySelector('li.active');
        // Note: scrollIntoView behavior might vary, 'nearest' is safer for hover
        if (activeItem) {
            activeItem.scrollIntoView({ block: 'center', behavior: 'smooth' });
        }
    },

    initPositioning() {
        // 動態定位函數
        const updatePosition = () => {
            if (!document.body.contains(this.container) || !this.fixedTocContainer) {
                return;
            }

            // 1. 顯示/隱藏邏輯：當使用者捲動超過文章內的 TOC 時才顯示
            const fixedTocRect = this.fixedTocContainer.getBoundingClientRect();
            const fixedTocBottom = fixedTocRect.bottom;

            if (fixedTocBottom < 0) {
                if (this.container.style.display === 'none') {
                    this.container.style.display = 'flex';
                    requestAnimationFrame(() => {
                        this.container.style.opacity = '1';
                    });
                }
            } else {
                this.container.style.opacity = '0';
                if (this.container.style.opacity === '0') {
                    this.container.style.display = 'none';
                }
            }

            // 2. 左側對齊邏輯：對齊文章內容 (.gh-content) 的左側
            // 優先找 gh-content，若無則找 h1 (通常都有 content)
            const content = document.querySelector('.gh-content') || document.querySelector('article');
            if (content) {
                const contentRect = content.getBoundingClientRect();
                // 設定左邊距位置 = 內容左邊界
                // 注意：如果視窗太窄導致 contentRect.left 很小，我們仍需保持最小邊距 (例如 20px)
                const leftPos = Math.max(20, contentRect.left);
                this.container.style.left = `${leftPos}px`;
                this.container.style.transform = 'none'; // 覆寫原本可能有的置中 transform
            }
        };

        window.addEventListener('scroll', updatePosition);
        window.addEventListener('resize', updatePosition);

        // 初始化延遲執行，確保 DOM 佈局完成
        setTimeout(updatePosition, 300);
    },

    updateActive(activeHeaderId) {
        Utils.updateActiveItems('.toc-floating', activeHeaderId);

        // 更新膠囊上的標題文字 (收合時顯示當前閱讀章節)
        const titleEl = this.container.querySelector('.toc-title');
        if (!titleEl) return;

        let newTitle = '';

        if (activeHeaderId) {
            const currentHeader = document.getElementById(activeHeaderId);
            if (currentHeader) {
                // 使用 innerText 獲取純文字，並過濾掉可能存在的隱藏元素
                newTitle = currentHeader.innerText.replace(/#\s*$/, '').trim();
            }
        }

        // Fallback：如果沒有抓到 active header，則顯示文章標題
        if (!newTitle) {
            newTitle = this.articleTitle || '目錄';
        }

        titleEl.textContent = newTitle;

        // 捲動更新 (只在 Hover 時觸發)
        if (this.container && this.container.matches(':hover')) {
            this.scrollToActive();
        }
    }
};

// ===== 手機版側邊目錄模塊 =====
const MobileTOC = {
    container: null,
    trigger: null,
    overlay: null,

    create() {
        if (!AppState.isArticlePage || !AppState.content ||
            window.innerWidth >= 1201 || AppState.headers.length < 2) {
            this.hideElements();
            return null;
        }

        this.container = document.querySelector('.mobile-toc-container');
        this.trigger = document.querySelector('.mobile-toc-trigger');
        this.overlay = document.querySelector('.mobile-toc-overlay');

        const content = document.querySelector('.mobile-toc-content');
        const close = document.querySelector('.mobile-toc-close');

        if (!this.container || !content || !this.trigger || !close || !this.overlay) {
            return null;
        }

        // 清空並重建內容
        content.innerHTML = '';
        const list = document.createElement('ul');
        list.className = 'toc-common-list';

        AppState.headers.forEach(header => {
            const item = Utils.createTocItem(header);
            list.appendChild(item);
        });

        content.appendChild(list);

        this.showElements();
        this.bindEvents();

        return this.container;
    },

    bindEvents() {
        const content = this.container.querySelector('.mobile-toc-content');
        const close = this.container.querySelector('.mobile-toc-close');

        // 開關目錄
        this.trigger.addEventListener('click', () => {
            this.show();
        });

        close.addEventListener('click', () => {
            this.hide();
        });

        this.overlay.addEventListener('click', () => {
            this.hide();
        });

        // 點擊導航
        content.querySelectorAll('.toc-common-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const targetId = link.getAttribute('href').substring(1);

                this.hide();
                setTimeout(() => {
                    Utils.scrollToHeader(targetId);
                }, 300);
            });
        });
    },

    show() {
        this.container.classList.add('active');
        this.overlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    },

    hide() {
        this.container.classList.remove('active');
        this.overlay.classList.remove('active');
        document.body.style.overflow = '';
    },

    showElements() {
        this.trigger.style.display = 'block';
        this.container.style.display = 'block';
        this.overlay.style.display = 'block';
    },

    hideElements() {
        const elements = [
            document.querySelector('.mobile-toc-trigger'),
            document.querySelector('.mobile-toc-container'),
            document.querySelector('.mobile-toc-overlay')
        ];

        elements.forEach(el => {
            if (el) el.style.display = 'none';
        });
    },

    updateActive(activeHeaderId) {
        Utils.updateActiveItems('.mobile-toc-container', activeHeaderId);
    }
};

// ===== JSON-LD 結構化資料（Article） =====
const JSONLD = {
    init() {
        if (!Features.on('jsonLd') || !AppState.isArticlePage) return;
        // 避免重複注入
        if (document.getElementById('injected-jsonld-article')) return;

        const getMeta = (prop) => document.querySelector(`meta[property="${prop}"]`)?.getAttribute('content') || '';
        const headline = getMeta('og:title') || document.querySelector('article h1, .post-full-title, .gh-content h1')?.textContent?.trim() || document.title;
        const url = getMeta('og:url') || window.location.href;
        const image = getMeta('og:image') || undefined;
        const description = getMeta('og:description') || document.querySelector('meta[name="description"]')?.getAttribute('content') || '';
        const datePublished = document.querySelector('meta[property="article:published_time"]')?.getAttribute('content') || document.querySelector('time[datetime]')?.getAttribute('datetime') || '';
        const dateModified = document.querySelector('meta[property="article:modified_time"]')?.getAttribute('content') || '';
        const author = document.querySelector('meta[name="author"]')?.getAttribute('content') || document.querySelector('a[rel="author"], .author-name')?.textContent?.trim() || undefined;
        const tags = Array.from(document.querySelectorAll('meta[property="article:tag"]')).map(m => m.getAttribute('content')).filter(Boolean);

        const data = {
            '@context': 'https://schema.org',
            '@type': 'Article',
            headline,
            url,
            image: image ? [image] : undefined,
            description,
            datePublished: datePublished || undefined,
            dateModified: dateModified || undefined,
            author: author ? { '@type': 'Person', name: author } : undefined,
            mainEntityOfPage: url,
            keywords: tags.length ? tags.join(',') : undefined
        };

        const script = document.createElement('script');
        script.type = 'application/ld+json';
        script.id = 'injected-jsonld-article';
        script.textContent = JSON.stringify(data);
        document.head.appendChild(script);
    }
};

// ===== 閱讀進度條模塊 =====
const ProgressBar = {
    bar: null,

    init() {
        this.bar = document.querySelector('.reading-progress-bar');

        if (!AppState.isArticlePage || !AppState.content) {
            this.hide();
            return;
        }

        if (!this.bar) return;

        this.bar.style.display = 'block';
        this.bindEvents();
        this.update();
    },

    bindEvents() {
        const updateProgress = () => this.update();
        window.addEventListener('scroll', updateProgress);
        window.addEventListener('resize', updateProgress);
    },

    update() {
        if (!AppState.content) return;

        const contentHeight = AppState.content.offsetHeight;
        const contentTop = AppState.content.offsetTop;
        const scrollPosition = window.scrollY;
        const windowHeight = window.innerHeight;

        let readHeight = scrollPosition - contentTop;
        if (readHeight < 0) readHeight = 0;

        const totalReadableHeight = contentHeight - windowHeight;
        if (totalReadableHeight <= 0) return;

        let percent = Math.min(100, Math.round((readHeight / totalReadableHeight) * 100));
        if (percent < 0) percent = 0;

        this.bar.style.width = percent + '%';
    },

    hide() {
        if (this.bar) this.bar.style.display = 'none';
    }
};

// ===== 回到頂部按鈕模塊 (含環狀進度條) =====
const BackToTop = {
    button: null,
    circle: null,
    radius: 24,
    circumference: 0,

    init() {
        this.button = document.getElementById('back-to-top');
        if (!this.button) return;

        this.circle = this.button.querySelector('.progress-ring__circle');
        if (this.circle) {
            this.circumference = 2 * Math.PI * this.radius;
            this.circle.style.strokeDasharray = `${this.circumference} ${this.circumference}`;
            this.circle.style.strokeDashoffset = this.circumference;
        }

        this.bindEvents();
        this.updateProgress(); // 初始化時檢查一次
    },

    bindEvents() {
        const scrollThreshold = 300;

        window.addEventListener('scroll', () => {
            this.updateProgress();
        });

        this.button.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    },

    updateProgress() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

        // 顯示/隱藏控制
        if (scrollTop > 300) {
            this.button.classList.add('visible');
        } else {
            this.button.classList.remove('visible');
        }

        // Calculate completion percentage
        let completion = 0;

        // 進度計算邏輯：以最後一個 H2 的結束位置為 100%
        const content = document.querySelector('.gh-content');
        if (content) {
            const h2s = content.querySelectorAll('h2');
            if (h2s.length > 0) {
                const lastH2 = h2s[h2s.length - 1];
                const targetScrollTop = (lastH2.offsetTop + lastH2.offsetHeight) - window.innerHeight;

                if (targetScrollTop > 0) {
                    const progress = scrollTop / targetScrollTop;
                    completion = Math.min(Math.max(progress, 0), 1);
                } else {
                    completion = 1;
                }
            } else {
                // Fallback: 整頁高度
                const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
                if (scrollHeight > 0) {
                    completion = Math.min(Math.max(scrollTop / scrollHeight, 0), 1);
                }
            }
        } else {
            // Fallback: 非文章頁面
            const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            if (scrollHeight > 0) {
                completion = Math.min(Math.max(scrollTop / scrollHeight, 0), 1);
            }
        }

        // GLOW EFFECT: Set box-shadow inline style directly
        if (this.button) {
            const glowBlur = Math.round(completion * 30); // 0-30px
            // DEBUG: Log values to console
            console.log('[BackToTop] completion:', completion, 'glowBlur:', glowBlur);
            // Use hardcoded color for reliability
            this.button.style.setProperty('box-shadow', `0 0 ${glowBlur}px color-mix(in srgb, var(--primary-color), transparent 20%)`, 'important');
        }
    },

    checkInitialPosition() {
        this.updateProgress();
    }
};
// ===== 【新增】標題錨點連結模組 =====
const HeadingAnchors = {
    init() {
        if (!AppState.isArticlePage || !AppState.content) return;
        // 僅在桌機建立標題錨點，手機版停用此功能
        if (window.innerWidth < 769) return;

        AppState.headers.forEach(header => {
            // 若已存在錨點，避免重複插入（因 SPA 可能多次 init）
            if (header.querySelector('a.heading-anchor-link')) return;
            // 確保標題有 ID
            Utils.ensureHeaderIds([header]);
            if (!header.id) return;

            // 創建錨點連結元素
            const anchor = document.createElement('a');
            anchor.className = 'heading-anchor-link';
            anchor.href = `#${header.id}`;
            anchor.setAttribute('aria-label', `Link to ${header.textContent}`);

            // 【最終版 v4】創建 SVG 向量圖示
            const iconSVG = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.72"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.72-1.72"></path></svg>';
            anchor.innerHTML = iconSVG; // 直接將 SVG 寫入

            // 創建提示框
            const tooltip = document.createElement('span');
            tooltip.className = 'tooltiptext';
            tooltip.textContent = 'Copy link';

            // 將提示框加到錨點連結中
            anchor.appendChild(tooltip);

            // 將錨點連結加到標題的最前面
            header.prepend(anchor);

            // 綁定點擊事件
            this.bindClickEvent(anchor, header, tooltip);
        });
    },

    bindClickEvent(anchor, header, tooltip) {
        anchor.addEventListener('click', (e) => {
            e.preventDefault();
            const url = `${window.location.origin}${window.location.pathname}#${header.id}`;

            navigator.clipboard.writeText(url).then(() => {
                tooltip.textContent = 'Copied!';
                tooltip.classList.add('visible');

                setTimeout(() => {
                    tooltip.textContent = 'Copy link';
                    tooltip.classList.remove('visible');
                }, 2000);
            }).catch(err => {
                tooltip.textContent = 'Error!';
                console.error('Failed to copy link: ', err);

                setTimeout(() => {
                    tooltip.textContent = 'Copy link';
                }, 2000);
            });
        });
    }
};

// ===== 分享功能 =====
const Share = {
    container: null,
    init() {
        if (!Features.on('shareButtons') || !AppState.isArticlePage || !AppState.content) return;
        if (document.getElementById('cx-share-bar')) return; // 去重

        const url = window.location.href;
        const title = document.querySelector('article h1, .post-full-title, .gh-content h1')?.textContent?.trim() || document.title;

        this.container = document.createElement('div');
        this.container.id = 'cx-share-bar';
        this.container.className = 'cx-share-bar';

        const makeLink = (href, iconClass, label) => {
            const a = document.createElement('a');
            a.href = href; a.target = '_blank'; a.rel = 'noopener noreferrer'; a.title = label;
            a.innerHTML = `<i class="${iconClass}"></i>`;
            return a;
        };

        // 行動原生分享
        const shareBtn = document.createElement('button');
        shareBtn.type = 'button';
        shareBtn.className = 'cx-share-native';
        shareBtn.innerHTML = '<i class="fas fa-share-alt"></i>';
        shareBtn.addEventListener('click', () => {
            if (navigator.share) {
                navigator.share({ title, url }).catch(() => { });
            } else {
                window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(title)}&url=${encodeURIComponent(url)}`, '_blank');
            }
        });

        const links = document.createElement('div');
        links.className = 'cx-share-links';
        links.appendChild(makeLink(`https://twitter.com/intent/tweet?text=${encodeURIComponent(title)}&url=${encodeURIComponent(url)}`, 'fab fa-x-twitter', 'Share to X'));
        links.appendChild(makeLink(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, 'fab fa-facebook', 'Share to Facebook'));
        links.appendChild(makeLink(`https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(url)}`, 'fab fa-linkedin', 'Share to LinkedIn'));
        links.appendChild(makeLink(`https://social-plugins.line.me/lineit/share?url=${encodeURIComponent(url)}`, 'fab fa-line', 'Share to LINE'));

        this.container.appendChild(shareBtn);
        this.container.appendChild(links);

        AppState.content.appendChild(this.container);
    }
};

// ===== 主控制器 =====
const AppController = {
    articleToc: null,
    floatingToc: null,
    mobileToc: null,

    init() {
        AppState.init();

        // 根據頁面類型初始化不同模塊
        if (AppState.isArticlePage) {
            ProgressBar.init();
            ContentLinks.init();
            JSONLD.init();
            CodeBlockEnhancer.init();
            ImageOptimize.init();
            TableResponsive.init();
            Breadcrumbs.init();
            HeadingAnchors.init();

            // 目錄初始化（桌面與手機）
            // 修正：必須賦值給 this 變數，否則 bindScrollEvents 抓不到
            const tocContainer = ArticleTOC.create();
            this.articleToc = tocContainer;

            if (tocContainer) {
                this.floatingToc = FloatingTOC.create(tocContainer);
                this.mobileToc = MobileTOC.create();
            }

            // 啟動捲動監聽
            this.bindScrollEvents();
        }

        // 全站通用功能
        BackToTop.init();
        Share.init();
        KitForm.init();
    },

    initTocModules() {
        // 保留此方法以防其他地方呼叫，但邏輯與 init 重複
        this.articleToc = ArticleTOC.create();

        if (this.articleToc) {
            this.floatingToc = FloatingTOC.create(this.articleToc);
            this.mobileToc = MobileTOC.create();
        }
    },

    bindScrollEvents() {
        let ticking = false;

        const updateAll = () => {
            if (!AppState.isArticlePage || AppState.headers.length < 2) return;

            const activeHeaderId = Utils.findActiveHeader(AppState.headers);

            // 即使 id 沒變，也可能需要更新 UI 狀態 (但為了效能，通常只在變動時更新)
            if (activeHeaderId !== AppState.activeHeaderId) {
                AppState.activeHeaderId = activeHeaderId;

                if (this.articleToc) ArticleTOC.updateActive(activeHeaderId);
                // 這裡原本有判斷 if (this.floatingToc)，但為了保險起見，直接呼叫模組方法 (模組內部會檢查 container 是否存在)
                FloatingTOC.updateActive(activeHeaderId);
                if (this.mobileToc) MobileTOC.updateActive(activeHeaderId);
            }

            ticking = false;
        };

        // ... (rest of function)

        const onScroll = () => {
            if (!ticking) {
                requestAnimationFrame(updateAll);
                ticking = true;
            }
        };

        window.addEventListener('scroll', onScroll);
        setTimeout(() => updateAll(), 500);
    }
};

// ===== 【新增】程式碼區塊增強模組 =====
const CodeBlockEnhancer = {
    init() {
        if (!AppState.content) return;

        const pres = AppState.content.querySelectorAll('pre');
        pres.forEach(pre => {
            // 避免重複處理
            if (pre.parentElement.classList.contains('code-block-wrapper')) {
                return;
            }

            const code = pre.querySelector('code');
            if (!code) return;

            // 1. 創建外層容器
            const wrapper = document.createElement('div');
            wrapper.className = 'code-block-wrapper';
            pre.parentNode.insertBefore(wrapper, pre);
            wrapper.appendChild(pre);

            // 2. 創建並加入語言標籤
            const langClass = Array.from(code.classList).find(c => c.startsWith('language-'));
            const lang = langClass ? langClass.replace('language-', '') : 'code';

            const langLabel = document.createElement('span');
            langLabel.className = 'code-lang-label';
            langLabel.textContent = lang;
            wrapper.appendChild(langLabel);

            // 3. 創建並加入複製按鈕
            const copyButton = document.createElement('button');
            copyButton.className = 'copy-code-button';
            copyButton.textContent = 'Copy';
            wrapper.appendChild(copyButton);

            // 4. 綁定複製事件
            copyButton.addEventListener('click', () => {
                navigator.clipboard.writeText(code.innerText).then(() => {
                    copyButton.textContent = 'Copied!';
                    copyButton.classList.add('copied');
                    setTimeout(() => {
                        copyButton.textContent = 'Copy';
                        copyButton.classList.remove('copied');
                    }, 2000);
                }).catch(err => {
                    copyButton.textContent = 'Error';
                    console.error('Failed to copy: ', err);
                });
            });
        });
    }
};


// ===== 圖片最佳化（lazy/async、提升首圖優先權） =====
const ImageOptimize = {
    init() {
        if (!Features.on('imageOptimize') || !AppState.content) return;
        const imgs = AppState.content.querySelectorAll('img');
        let firstHigh = false;
        imgs.forEach(img => {
            if (!img.hasAttribute('loading')) img.setAttribute('loading', 'lazy');
            if (!img.hasAttribute('decoding')) img.setAttribute('decoding', 'async');
            // 近視窗頂部的第一張圖給高優先權
            if (!firstHigh) {
                const rect = img.getBoundingClientRect();
                const top = rect.top + window.scrollY;
                if (top < window.scrollY + 1200) {
                    img.setAttribute('fetchpriority', 'high');
                    firstHigh = true;
                }
            }
        });
    }
};

// ===== 表格在小螢幕可橫向捲動 =====
const TableResponsive = {
    init() {
        if (!Features.on('tableResponsive') || !AppState.content) return;
        AppState.content.querySelectorAll('table').forEach(tbl => {
            if (tbl.closest('.cx-table-responsive')) return;
            const wrap = document.createElement('div');
            wrap.className = 'cx-table-responsive';
            tbl.parentNode.insertBefore(wrap, tbl);
            wrap.appendChild(tbl);
        });
    }
};

// ===== 麵包屑導航 (Breadcrumbs) =====
const Breadcrumbs = {
    init() {
        // 簡單實作：如果需要麵包屑，可以在這裡動態生成
        // 目前先留空，視需求實作
    }
};

// ===== 閱讀時間估算 (ReadingInfo) =====
const ReadingInfo = {
    init() {
        // Ghost 原生已有 reading_time helper，這裡可以做額外增強
    }
};
// ===== Hero Title 解析模組 (僅處理 || 換行) =====
const HeroTitle = {
    init() {
        const elements = document.querySelectorAll('.hero-title[data-title]');
        elements.forEach(el => {
            const rawText = el.getAttribute('data-title');
            if (rawText) {
                // 用 || 分割換行，用 <br> 連接
                el.innerHTML = rawText.split('||').map(line => line.trim()).join('<br>');
            }
        });
    }
};

// ===== Hero Markdown 解析模組 (僅作用於 .hero-markdown 元素) =====
const HeroMarkdown = {
    init() {
        // 只選取有 .hero-markdown 類別的元素
        const elements = document.querySelectorAll('.hero-markdown[data-markdown]');
        elements.forEach(el => {
            const rawText = el.getAttribute('data-markdown');
            if (rawText) {
                el.innerHTML = this.parse(rawText);
            }
        });
    },

    parse(text) {
        if (!text) return '';

        // 用 || 分割成行（因為 Ghost 欄位是單行）
        let lines = text.split('||');
        let result = [];
        let inUl = false;
        let inOl = false;

        lines.forEach(line => {
            line = line.trim();
            if (!line) return;

            // 檢查是否是無序列表 (- item)
            const ulMatch = line.match(/^-\s+(.+)$/);
            if (ulMatch) {
                if (!inUl) {
                    if (inOl) { result.push('</ol>'); inOl = false; }
                    result.push('<ul class="hero-list">');
                    inUl = true;
                }
                result.push(`<li>${this.parseInline(ulMatch[1])}</li>`);
                return;
            }

            // 檢查是否是有序列表 (1. item)
            const olMatch = line.match(/^\d+\.\s+(.+)$/);
            if (olMatch) {
                if (!inOl) {
                    if (inUl) { result.push('</ul>'); inUl = false; }
                    result.push('<ol class="hero-list">');
                    inOl = true;
                }
                result.push(`<li>${this.parseInline(olMatch[1])}</li>`);
                return;
            }

            // 關閉之前的列表
            if (inUl) { result.push('</ul>'); inUl = false; }
            if (inOl) { result.push('</ol>'); inOl = false; }

            // 檢查是否是標題 (# 到 ######)
            const headingMatch = line.match(/^(#{1,6})\s+(.+)$/);
            if (headingMatch) {
                const level = headingMatch[1].length;
                const content = this.parseInline(headingMatch[2]);
                result.push(`<h${level} class="hero-heading">${content}</h${level}>`);
                return;
            }

            // 一般文字行
            result.push(`<p>${this.parseInline(line)}</p>`);
        });

        // 關閉未關閉的列表
        if (inUl) result.push('</ul>');
        if (inOl) result.push('</ol>');

        return result.join('');
    },

    parseInline(text) {
        return text
            // 粗體 **text** 或 __text__ (先處理)
            .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
            .replace(/__(.+?)__/g, '<strong>$1</strong>')

            // 斜體 *text* 或 _text_
            .replace(/\*([^*]+)\*/g, '<em>$1</em>')
            .replace(/_([^_]+)_/g, '<em>$1</em>')

            // 連結 [text](url)
            .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>')

            // 行內代碼 `code`
            .replace(/`([^`]+)`/g, '<code>$1</code>');
    }
};


// ===== 表格欄位 Hover 連動效果 =====
const TableHover = {
    init() {
        const tables = document.querySelectorAll('.gh-content table');
        tables.forEach(table => this.bindTable(table));
    },

    bindTable(table) {
        const cells = table.querySelectorAll('td');

        cells.forEach(cell => {
            cell.addEventListener('mouseenter', () => {
                // 找到這個 cell 的欄位索引
                const columnIndex = this.getCellColumnIndex(cell);
                // 高亮對應的表頭
                this.highlightHeader(table, columnIndex, true);
            });

            cell.addEventListener('mouseleave', () => {
                const columnIndex = this.getCellColumnIndex(cell);
                this.highlightHeader(table, columnIndex, false);
            });
        });
    },

    getCellColumnIndex(cell) {
        let index = 0;
        let sibling = cell.previousElementSibling;
        while (sibling) {
            index++;
            sibling = sibling.previousElementSibling;
        }
        return index;
    },

    highlightHeader(table, columnIndex, isActive) {
        // 先找 thead th，如果沒有 thead 則找第一行的 td
        let headerRow = table.querySelector('thead tr');
        if (!headerRow) {
            headerRow = table.querySelector('tbody tr:first-child');
        }

        if (!headerRow) return;

        const headerCells = headerRow.querySelectorAll('th, td');
        if (headerCells[columnIndex]) {
            if (isActive) {
                headerCells[columnIndex].classList.add('column-hover');
            } else {
                headerCells[columnIndex].classList.remove('column-hover');
            }
        }
    }
};

// ===== 初始化 =====
document.addEventListener('DOMContentLoaded', () => {
    HeroTitle.init();     // 首頁標題換行
    HeroMarkdown.init();  // 首頁 Markdown 解析
    TableHover.init();    // 表格欄位連動效果
    AppController.init();
});

// SPA 頁面變化檢測
let lastUrl = location.href;
new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
        lastUrl = url;
        setTimeout(() => {
            AppController.init();
        }, 500);
    }
}).observe(document, { subtree: true, childList: true });
